// Global 2D array to store baby data
const babyData = [];

// References to DOM elements
const nameInput = document.getElementById("name");
const sexInput = document.getElementById("sex");
const babyTable = document.getElementById("babyTable");
const babyTableBody = document.querySelector("#babyTable tbody");
const countsDisplay = document.getElementById("counts");

// Function to render the table based on babyData
function renderTable() {
    babyTableBody.innerHTML = ""; // Clear table

    if (babyData.length === 0) {
        babyTable.style.display = "none"; // Hide table if no data
    } else {
        babyTable.style.display = "table"; // Show table when data exists
        babyData.forEach(([name, sex]) => {
            const row = document.createElement("tr");
            row.className = sex === "male" ? "male" : "female";

            const nameCell = document.createElement("td");
            nameCell.textContent = name;

            const sexCell = document.createElement("td");
            sexCell.textContent = sex;

            row.appendChild(nameCell);
            row.appendChild(sexCell);
            babyTableBody.appendChild(row);
        });
    }
}

// Function to update counts display
function updateCounts() {
    const boys = babyData.filter(([_, sex]) => sex === "male").length;
    const girls = babyData.filter(([_, sex]) => sex === "female").length;
    countsDisplay.textContent = `Boys: ${boys} Girls: ${girls}`;
    countsDisplay.style.display = "block"; // Show counts
}

// Event listener for Add Baby button
document.getElementById("addBaby").addEventListener("click", () => {
    const name = nameInput.value.trim();
    const sex = sexInput.value;

    if (!name) {
        alert("Please enter a name.");
        return;
    }

    if (babyData.some(([existingName]) => existingName === name)) {
        alert("A baby with this name already exists.");
        return;
    }

    babyData.push([name, sex]);
    renderTable();
    nameInput.value = "";
});

// Event listener for Remove Baby button
document.getElementById("removeBaby").addEventListener("click", () => {
    if (babyData.length > 0) {
        babyData.pop();
        renderTable();
    }
});

// Event listener for Empty List button
document.getElementById("emptyList").addEventListener("click", () => {
    babyData.length = 0; // Clear the array
    renderTable();
    countsDisplay.style.display = "none"; // Hide counts
});

// Event listener for Count By Sex button
document.getElementById("countBySex").addEventListener("click", updateCounts);
